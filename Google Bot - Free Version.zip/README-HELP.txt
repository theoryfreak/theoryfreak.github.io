This File Was Downloaded From https://theoryfreak.com

You may need to register OCX Files in order for the program to run.

If you get a message about Missing or Unregistered OCX File Then Please Follow These Directions. 

There Is The Need OCX Files Within This Folder.

There Is Also A .BAT File Within This Folder.

First Try Running The RegisterOCX.BAT, Then Open The Program.

If You Are Still Experiencing Issues, Then Please Following This Path C:\Windows\System32 And Move The .OCX Files From This Folder To System32. Now Run The RegisterOCX.Bat File and Try Opening The Program.


I Hope You Enjoy! - TheoryFreak

If you are still having any issues or would just like to leave a comment or questions, You may by emailing me anytime at pulse@msn.com